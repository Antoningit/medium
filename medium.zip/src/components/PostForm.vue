<template>
  <div class="container" style="max-width: 800px">
    <b-field label="Title">
      <b-input v-model="title"></b-input>
    </b-field>
    <b-field label="Description">
      <b-input type="textarea" v-model="description"></b-input>
    </b-field>
    <b-button type="is-primary">Save</b-button>
    {{editPost}}
  </div>
</template>
<script>
export default {
  props: ['editPost'],
  data() {
    return {
      title: "",
      description: ""
    };
  },
  mounted() {
      if (this.editPost != null) {
          const post = this.$store.getters.getPost(this.editPost)
          console.log(post)
/*           this.title = post.title
          this.description = post.description */
      }
  }
};
</script>
<template>
  <div>
    <h1>Create/Edit</h1>
    <PostForm :editPost='postIndex' />
  </div>
</template>

<script>
import PostForm from '../components/PostForm'
export default {
  data() {
    return {
      postIndex: null
    }
  },
  components: {
    PostForm
  },
  mounted() {
    /* if (!this.$store.getters.authStatus) {
      this.$router.push('/')
    } */
    if (this.$route?.query?.index >= 0) {
      this.postIndex = +this.$route.query.index
    }
  }
}
</script>

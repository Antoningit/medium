import axios from 'axios'

export default {
    state: {
        postsData: []
    },
    mutations: {
        SET_POSTS_TO_STATE: (state, posts) => {
            state.postsData = posts
        },
        CLAPS(state, index) {
            state.postsData[index].claps++
        },
        DELETE_POST(state, index) {
            state.postsData.splice(index, 1)
        }
    },
    actions: {
        GET_POSTS_FROM_API({ commit }) {
            return axios('http://localhost:3000/posts', {
                method: 'GET'
            })
                .then((posts) => {
                    commit('SET_POSTS_TO_STATE', posts.data)
                    return posts
                })
                .catch((error) => {
                    console.log(error)
                    return error
                })
        },
        claps({ commit }, index) {
            commit('CLAPS', index)
        },
        deletePost({ commit }, index) {
            commit('DELETE_POST', index)
        }
    },
    getters: {
        POSTS(state) {
            return state.postsData
        },
        getPost: (state) => (index) => {
            return state.postsData[index]
        }
    }
}